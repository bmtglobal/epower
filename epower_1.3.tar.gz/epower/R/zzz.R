
.onLoad <- function(libname, pkgname) {
  packageStartupMessage("‘epower’ is freely available to users under licence which \n",
"precludes the incorporation of the ‘epower’ code into other programs which are \n",
"subsequently sold or used for commercial purposes. Please include the following \n",
"acknowledgment when using ‘epower’:  Analyses were carried out using the software \n",
"‘epower’ V1.3 (BMT 2019) as described in Fisher et al (2019) and (BMT 2019) and based \n",
"on the statistical programming platform R (R-Core Team, 2019). ‘epower’ has been \n",
"developed jointly by BMT, the Australian Institute of marine Science and Queensland \n",
"University of Technology. BMT, the Australian Institute of Marine Science and Queensland \n",
"University of Technology accept no liability or responsibility for in respect of any use \n",
"of or reliance upon this software.")
}
