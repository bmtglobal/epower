

require(epower)
fitData()#excelInFile="ignore/SULPH_test_1.xlsx")
assessPower()

